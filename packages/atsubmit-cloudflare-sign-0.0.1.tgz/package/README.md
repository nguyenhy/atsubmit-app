# @atsubmit/internal-sign

A production-grade, deterministic request signing and verification utility designed for **Zero Trust** internal communication. Optimized for Cloudflare Workers (Edge) and Node.js runtimes.

---

## 🔒 Why this package exists

In a modern microservices architecture (especially with Cloudflare Service Bindings), it is tempting to rely on "network-level" isolation for security. However, relying solely on the execution boundary is a single point of failure.

**`internal-sign` provides an application-level identity layer:**

1.  **Defense-in-Depth:** Even if a private service binding is accidentally exposed via a public route or a configuration error, the service remains protected because it requires a valid cryptographic signature.
2.  **Explicit Trust:** Trust is derived from a shared secret, not just "where the request came from."
3.  **Integrity & Freshness:** Every request is cryptographically bound to its method, path, query parameters, body, and timestamp—preventing tampering and replay attacks.

---

## 🚀 Use Cases

-   **Worker-to-Worker (Cloudflare):** Secure communication between a Main Worker and specialized Sub-workers via Service Bindings.
-   **Node-to-Edge:** Securely calling Cloudflare Workers from a centralized Node.js backend.
-   **Edge-to-Node:** Verifying requests from Cloudflare Workers at your origin server.

---

## ✨ Key Features

-   **Edge-Ready:** Fully compatible with Cloudflare Workers (requires `nodejs_compat` flag).
-   **Deterministic Canonicalization:** Handles header casing (case-insensitive) and query parameter ordering (sorted) to ensure consistency across different environments.
-   **Production-Grade Security:**
    -   Uses HMAC-SHA256 for signing.
    -   Constant-time signature comparison (`timingSafeEqual`) to prevent timing attacks.
    -   Newline-delimited canonical strings to prevent header injection collisions.
    -   Automatic DoS protection against malformed signatures.
    -   CRLF rejection in header values.
-   **Zero Dependencies:** Minimal footprint, utilizing native `subtle.crypto` and `node:crypto` APIs.

---

## 🛠 Usage

### 1. Installation

This package is intended for internal use. It is typically consumed via a local tarball or a private registry.

```bash
# Example: Installing from a local build
npm install ../tgz/internal-sign-1.0.0.tgz
```

### 2. Signing a Request (Client Side)

```typescript
import { signRequest } from '@atsubmit/internal-sign';

const secret = process.env.INTERNAL_SIGN_SECRET;
const url = new URL('https://sub-worker.internal/process?b=2&a=1');

const signed = await signRequest({
  method: 'POST',
  url: url,
  body: JSON.stringify({ task: 'compute' }),
  headers: {
    'Content-Type': 'application/json',
    'X-Trace-ID': '12345'
  },
  secret: secret,
});

// `signed.headers` now contains:
// - x-hdr-vs: Protocol version
// - x-hdr-ts: Timestamp (ms)
// - x-hdr-signed: List of headers included in the signature
// - x-hdr-sign: The HMAC-SHA256 signature (Base64)

// Send the request using the signed headers
const response = await fetch(signed.url, {
  method: signed.method,
  headers: signed.headers,
  body: signed.body,
});
```

### 3. Verifying a Request (Server Side / Worker)

In Cloudflare Workers, ensure the `nodejs_compat` flag is enabled in your `wrangler.toml`.

```typescript
import { verifyRequest } from '@atsubmit/internal-sign';

export default {
  async fetch(request, env) {
    const { method, url, headers } = request;
    const body = await request.text();

    const result = await verifyRequest({
      method,
      url: new URL(url),
      headers: Object.fromEntries(headers), // Standardize headers
      body,
      secret: env.INTERNAL_SIGN_SECRET,
      maxSkewMs: 60000, // 1 minute allowed clock drift
    });

    if (!result.valid) {
      console.error(`Verification failed: ${result.error}`);
      return new Response('Unauthorized', { status: 401 });
    }

    // Process the trusted request...
    return new Response('OK');
  }
}
```

---

## 📐 The Signing Protocol (Canonicalization)

To ensure both sides produce the exact same signature, `internal-sign` generates a canonical string in this strict format:

```text
HTTP_METHOD
PATHNAME (e.g., /api/v1)
SORTED_QUERY_STRING (e.g., ?a=1&b=2)
LOWERCASE_HEADER_KEY_1:VALUE_1
LOWERCASE_HEADER_KEY_2:VALUE_2
...
REQUEST_BODY
TIMESTAMP
```

*Note: The signing secret is used as the HMAC key and is **never** included in this string.*

---

## 🛡 Security Best Practices

1.  **Secret Rotation:** Use Cloudflare Secret Management. Rotate secrets regularly.
2.  **Short Skew:** For internal Cloudflare-to-Cloudflare communication, set `maxSkewMs` to 30-60 seconds to minimize the replay window.
3.  **Strict Filtering:** The library automatically ignores volatile headers (like `User-Agent`, `Authorization`, `Connection`) during signing to prevent accidental mismatches caused by proxies.

---

## 🧪 Development

-   **Test:** `npm test` (Runs core logic)
-   **Security Audit:** `npm run test:all` (Runs 24+ tests including security and regression checks)
-   **Build:** `npm run build` (Produces `dist/` for Node.js and Edge)
-   **Sync Version:** `npm run sync:version` (Keeps `src/version.ts` in sync with `package.json`)

---

## ⚖ License

Internal Use Only - @atsubmit
